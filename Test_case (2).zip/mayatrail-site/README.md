# MayaTrail — website

Cloud attack emulation for detection engineers. Static site (HTML + a little React via CDN). No build step.

## Run it / share it

The pages load React + Babel from a CDN and pull in local `.jsx`/`.css` files, so they must be **served over http(s)**, not opened with `file://` (the browser blocks loading the `.jsx` modules from disk, which is why the hero/run can look blank on a raw double-click).

**Easiest: GitHub Pages**
1. Push this folder to a repo.
2. Settings → Pages → deploy from branch (root).
3. Open the Pages URL → it lands on `index.html` which redirects to the landing page.

**Local preview**
```bash
cd mayatrail-site
python3 -m http.server 8000
# open http://localhost:8000
```

## Pages
- `MayaTrail Landing.html` — landing (Vault hero — scroll to open; node-mark seam; Tweaks panel)
- `MayaTrail Run.html` — AMBERSQUID emulation playback (plan → run → evidence + IR playbook)
- `MayaTrail Playbook.html` — the generated AMBERSQUID IR playbook (run artifact)
- `MayaTrail Scenarios.html` · `MayaTrail Coverage.html` · `MayaTrail Research.html`
- `MayaTrail Pricing.html`
- Decks (1920×1080, arrow keys): `MayaTrail Pitch.html`, `MayaTrail Market.html`
- Internal docs: `MayaTrail GTM.html`, `MayaTrail Battlecards.html`, `MayaTrail Demo Script.html`

## Assets
- `mayatrail-base.css` — shared tokens + nav/footer
- `landing-vault.jsx` + `tweaks-panel.jsx` — landing hero + tweaks
- `run-experience.jsx` — run page app
- `deck-stage.js` — slide-deck shell (Pitch/Market)
- `favicon.svg` — node-mark favicon
- `logo/` — logo files (lockups + marks, dark/light)

## Brand
- Node-correlation mark · cool `#6aa8ff`, hot/breach `#ff4b6e`, deep (light bg) `#2f5fa8`
- Wordmark: "MayaTrail" with a gentle trail-fade on "Trail"
